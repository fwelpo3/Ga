// Szenen & Zentralfunktionen
export const SCENE_MAIN_GROUP = 8;
export const CENTRAL_MAIN_GROUP = 9;
